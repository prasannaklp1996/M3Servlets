package org.cap.service;

import java.util.ArrayList;
import java.util.List;

import org.cap.dao.ILoginDAO;
import org.cap.dao.LoginDAO;
import org.cap.model.BusBean;
import org.cap.model.LoginBean;
import org.cap.model.RouteMapBean;
import org.cap.model.TransactionBean;

public class LoginServiceImpl implements ILoginService {
	ILoginDAO loginDAO = new LoginDAO();
	@Override
	public boolean checkUser(LoginBean loginBean) {
		if(loginDAO.checkUser(loginBean)) {
			return true;
		}else {
			return false;
		}
		
		
	}
	@Override
	public BusBean createRequest(BusBean busBean) {
		if(loginDAO.createRequest(busBean) != null)
			return busBean;
      return null;
		
	}
	@Override
	public List<RouteMapBean> listAllRoutes() {
		List<RouteMapBean> routeList=new ArrayList<>();
		routeList = loginDAO.listAllRoutes();
		return routeList;
	}
	@Override
	public RouteMapBean addRoute(RouteMapBean newroute) {
		if(loginDAO.addRoute(newroute)!=null) {
			return newroute;
		}
		return null;
	}
	@Override
	public List<String> PendingReqServlet() {
		List<String> list=new ArrayList<>();
		list=loginDAO.PendingReqServlet();
		return list;
	}
	@Override
	public List<BusBean> pendingDetails() {
		List<BusBean> pendingList=loginDAO.pendingDetails();
		if(pendingList!=null)
			return pendingList;
		
		return null;
		
	}
	@Override
	public List<BusBean> pendingDetailsOfEmp(String empid) {
		List<BusBean> pendingList=loginDAO.pendingDetailsOfEmp(empid);
		if(pendingList!=null)
			return pendingList;
		return null;
	}
	@Override
	public Integer transaction(TransactionBean transaction) {
		Integer transaction_id=loginDAO.transaction(transaction);
		return transaction_id;
	}

}
