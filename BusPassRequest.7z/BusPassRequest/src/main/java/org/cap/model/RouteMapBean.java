package org.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;



@Table(name="routemap")
@Entity
public class RouteMapBean {
	@Id
	
	private int routeid;
	@OneToMany(mappedBy="route",targetEntity=TransactionBean.class,cascade=CascadeType.ALL,fetch=FetchType.LAZY)
	private List<TransactionBean> transactions=new ArrayList<>();
	@OneToOne
	@JoinColumn(name="Fk")
	private BusBean bus;
	
	private String routepath;
	private int occseats;
	private int totalseats;
	private String busno;
	private String busdriver;
	private int totalkm;
	public RouteMapBean() {
		super();
	}
	
	
	public RouteMapBean(int routeid,BusBean bus, String routepath, int occseats,
			int totalseats, String busno, String busdriver, int totalkm) {
		super();
		this.routeid = routeid;
		
		this.bus = bus;
		this.routepath = routepath;
		this.occseats = occseats;
		this.totalseats = totalseats;
		this.busno = busno;
		this.busdriver = busdriver;
		this.totalkm = totalkm;
	}


	public RouteMapBean(String routepath, int occseats, int totalseats, String busno, String busdriver, int totalkm) {
		super();
		this.routepath = routepath;
		this.occseats = occseats;
		this.totalseats = totalseats;
		this.busno = busno;
		this.busdriver = busdriver;
		this.totalkm = totalkm;
	}
	

	public RouteMapBean(int routeid, String routepath, int occseats, int totalseats, String busno, String busdriver,
			int totalkm) {
		super();
		this.routeid = routeid;
		this.routepath = routepath;
		this.occseats = occseats;
		this.totalseats = totalseats;
		this.busno = busno;
		this.busdriver = busdriver;
		this.totalkm = totalkm;
	}

	public int getRouteid() {
		return routeid;
	}
	public void setRouteid(int routeid) {
		this.routeid = routeid;
	}
	public String getRoutepath() {
		return routepath;
	}
	public void setRoutepath(String routepath) {
		this.routepath = routepath;
	}
	public int getOccseats() {
		return occseats;
	}
	public void setOccseats(int occseats) {
		this.occseats = occseats;
	}
	public int getTotalseats() {
		return totalseats;
	}
	public void setTotalseats(int totalseats) {
		this.totalseats = totalseats;
	}
	public String getBusno() {
		return busno;
	}
	public void setBusno(String busno) {
		this.busno = busno;
	}
	public String getBusdriver() {
		return busdriver;
	}
	public void setBusdriver(String busdriver) {
		this.busdriver = busdriver;
	}
	public int getTotalkm() {
		return totalkm;
	}
	public void setTotalkm(int d) {
		this.totalkm = d;
	}
	@Override
	public String toString() {
		return "RouteMapBean [routeid=" + routeid + ", routepath=" + routepath + ", occseats=" + occseats
				+ ", totalseats=" + totalseats + ", busno=" + busno + ", busdriver=" + busdriver + ", totalkm="
				+ totalkm + "]";
	}
	

}
