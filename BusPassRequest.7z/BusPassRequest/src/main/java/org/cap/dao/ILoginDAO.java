package org.cap.dao;

import java.util.List;

import org.cap.model.BusBean;
import org.cap.model.LoginBean;
import org.cap.model.RouteMapBean;
import org.cap.model.TransactionBean;

public interface ILoginDAO {
	public abstract boolean checkUser(LoginBean loginBean);
	public abstract BusBean createRequest(BusBean passRequestBean) ;
	public abstract List<RouteMapBean> listAllRoutes();
	public abstract RouteMapBean addRoute(RouteMapBean newroute);
	public abstract List<String> PendingReqServlet();
	
	public abstract List<BusBean> pendingDetails();
	public abstract List<BusBean> pendingDetailsOfEmp(String empid);
	public abstract Integer transaction(TransactionBean transaction);

}
